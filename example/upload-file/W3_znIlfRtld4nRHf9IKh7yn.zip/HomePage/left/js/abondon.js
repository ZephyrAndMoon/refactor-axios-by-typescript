let flag = true;
let flagTwo = true

  
  // 左侧区域点击翻页
  $("#area").click(function () {
    console.log('ok')
    if (flag) {
      $('.box-left #content').css('transform', 'translateX(1196px)')
      $('.box-left #state').css('transform', 'translateX(0px)')
      flag = !flag;
    } else {
      $('.box-left #content').css('transform', 'translateX(0px)')
      $('.box-left #state').css('transform', 'translateX(-1195px)')
      flag = !flag;
    }
  })

  // 右侧区域点击翻页
  $("#area-two").click(function () {
    console.log('ok')
    if (flagTwo) {
      $('.box-right #before').css('transform', 'translateX(-1200px)')
      $('.box-right #after').css('transform', 'translateX(0px)')
      flagTwo = !flagTwo;
    } else {
      $('.box-right #before').css('transform', 'translateX(0px)')
      $('.box-right #after').css('transform', 'translateX(1200px)')
      flagTwo = !flagTwo;
    }
  })

  $('.middle-img').click(function () {
    $('#video').css('display', 'block')
    $('#mask').css('display', 'block')
    $('#video')[0].play()
    $('.middle-img').css('display', 'none')
  })

  $('.bottom-base .back').click(function () {
    let exist = $('.bottom-base .back img').attr('src').indexOf('forbid')
    let conditions = $('.bottom-base .active').attr('page')
    if (exist !== -1) {
      return
    }
    $('.bottom-base .pre img').attr('src', './left/imgs/left.png')
    $('.bottom-base [page]').removeClass('active')
    switch (conditions) {
      case "1":
        $('.bottom-base [page=2]').addClass('active')
        break;
      case "2":
        $('.bottom-base [page="3"]').addClass('active')
        $('.bottom-base .back img').attr('src', './left/imgs/right@forbid.png')
        break;
      default:
        break;
    }
  })

  $('.bottom-base .pre').click(function () {
    let exist = $('.bottom-base .pre img').attr('src').indexOf('forbid')
    let conditions = $('.bottom-base .active').attr('page')
    if (exist !== -1) {
      return
    }
    $('.bottom-base .back img').attr('src', './left/imgs/right.png')
    $('.bottom-base [page]').removeClass('active')
    switch (conditions) {
      case "2":
        $('.bottom-base [page=1]').addClass('active')
        $('.bottom-base .pre img').attr('src', './left/imgs/left@forbid.png')
        break;
      case "3":
        $('.bottom-base [page="2"]').addClass('active')
        break;
      default:
        break;
    }
  })

  $('.bottom-unique .back').click(function () {
    let exist = $('.bottom-unique .back img').attr('src').indexOf('forbid')
    let conditions = $('.bottom-unique .active').attr('page')
    if (exist !== -1) {
      return
    }
    $('.bottom-unique .pre img').attr('src', './left/imgs/left.png')
    $('.bottom-unique [page]').removeClass('active')
    switch (conditions) {
      case "1":
        $('.bottom-unique [page=2]').addClass('active')
        break;
      case "2":
        $('.bottom-unique [page="3"]').addClass('active')
        $('.bottom-unique .back img').attr('src', './left/imgs/right@forbid.png')
        break;
      default:
        break;
    }
  })

  $('.bottom-unique .pre').click(function () {
    let exist = $('.bottom-unique .pre img').attr('src').indexOf('forbid')
    let conditions = $('.bottom-unique .active').attr('page')
    if (exist !== -1) {
      return
    }
    $('.bottom-unique .back img').attr('src', './left/imgs/right.png')
    $('.bottom-unique [page]').removeClass('active')
    switch (conditions) {
      case "2":
        $('.bottom-unique [page=1]').addClass('active')
        $('.bottom-unique .pre img').attr('src', './left/imgs/left@forbid.png')
        break;
      case "3":
        $('.bottom-unique [page="2"]').addClass('active')
        break;
      default:
        break;
    }
  })

  // 南平
  $('.nanping-area').mouseover(function () {
    $('.nanping').css('width', '575px')
    $('.nanping').css('height', '263px')
    $('.nanping').css('left', '55px')
    $('.nanping').css('top', '95px')
    $('.nanping').attr('src', './left/imgs/nanping@after.png')
  })

  $('.nanping-area').mouseout(function () {
    $('.nanping').css('width', '562px')
    $('.nanping').css('height', '245px')
    $('.nanping').css('left', '55px')
    $('.nanping').css('top', '100px')
    $('.nanping').attr('src', './left/imgs/nanping.png')
  })

  // 宁德
  $('.ningde-area').mouseover(function () {
    $('.ningde').attr('src', './left/imgs/ningde@after.png')
    $('.ningde').css('left', '546px')
    $('.ningde').css('top', '126px')
  })

  $('.ningde-area').mouseout(function () {
    $('.ningde').attr('src', './left/imgs/ningde.png')
    $('.ningde').css('left', '545px')
    $('.ningde').css('top', '129px')
  })


  // 三明
  $('.sanming-area').mouseover(function () {
    $('.sanming').attr('src', './left/imgs/sanming@after.png')
    $('.sanming').css('width', '516px')
    $('.sanming').css('height', '227px')
    $('.sanming').css('left', '55px')
    $('.sanming').css('top', '217px')
  })

  $('.sanming-area').mouseout(function () {
    $('.sanming').attr('src', './left/imgs/sanming.png')
    $('.sanming').css('width', '503px')
    $('.sanming').css('height', '210px')
    $('.sanming').css('left', '58px')
    $('.sanming').css('top', '225px')
  })

  // 福州
  $('.fuzhou-area').mouseover(function () {
    $('.fuzhou').attr('src', './left/imgs/fuzhou@after.png')
    $('.fuzhou').css('width', '634px')
    $('.fuzhou').css('height', '229px')
    $('.fuzhou').css('left', '523px')
    $('.fuzhou').css('top', '227px')
  })

  $('.fuzhou-area').mouseout(function () {
    $('.fuzhou').attr('src', './left/imgs/fuzhou.png')
    $('.fuzhou').css('width', '614px')
    $('.fuzhou').css('height', '211px')
    $('.fuzhou').css('left', '531px')
    $('.fuzhou').css('top', '236px')
  })

  // 龙岩
  $('.longyan-area').mouseover(function () {
    $('.longyan').attr('src', './left/imgs/longyan@after.png')
    $('.longyan').css('width', '429px')
    $('.longyan').css('height', '232px')
    $('.longyan').css('left', '54px')
    $('.longyan').css('top', '334px')
  })

  $('.longyan-area').mouseout(function () {
    $('.longyan').attr('src', './left/imgs/longyan.png')
    $('.longyan').css('width', '416px')
    $('.longyan').css('height', '214px')
    $('.longyan').css('left', '57px')
    $('.longyan').css('top', '341px')
  })

  // 莆田
  $('.putian-area').mouseover(function () {
    $('.putian').attr('src', './left/imgs/putian@after.png')
    $('.putian').css('width', '616px')
    $('.putian').css('height', '109px')
    $('.putian').css('left', '527px')
    $('.putian').css('top', '385px')
  })

  $('.putian-area').mouseout(function () {
    $('.putian').attr('src', './left/imgs/putian.png')
    $('.putian').css('width', '605px')
    $('.putian').css('height', '91px')
    $('.putian').css('left', '537px')
    $('.putian').css('top', '392px')
  })

  // 泉州
  $('.quanzhou-area').mouseover(function () {
    $('.quanzhou').attr('src', './left/imgs/quanzhou@after.png')
    $('.quanzhou').css('width', '530px')
    $('.quanzhou').css('height', '216px')
    $('.quanzhou').css('left', '438px')
    $('.quanzhou').css('top', '369px')
  })

  $('.quanzhou-area').mouseout(function () {
    $('.quanzhou').attr('src', './left/imgs/quanzhou.png')
    $('.quanzhou').css('width', '518px')
    $('.quanzhou').css('height', '205px')
    $('.quanzhou').css('left', '448px')
    $('.quanzhou').css('top', '380px')
  })

  // 漳州
  $('.zhangzhou-area').mouseover(function () {
    $('.zhangzhou').css('width', '590px')
    $('.zhangzhou').css('height', '245px')
    $('.zhangzhou').css('left', '374px')
    $('.zhangzhou').css('top', '453px')
    $('.zhangzhou').attr('src', './left/imgs/zhangzhou@after.png')
  })

  $('.zhangzhou-area').mouseout(function () {
    $('.zhangzhou').css('width', '579px')
    $('.zhangzhou').css('height', '233px')
    $('.zhangzhou').css('left', '384px')
    $('.zhangzhou').css('top', '464px')
    $('.zhangzhou').attr('src', './left/imgs/zhangzhou.png')
  })