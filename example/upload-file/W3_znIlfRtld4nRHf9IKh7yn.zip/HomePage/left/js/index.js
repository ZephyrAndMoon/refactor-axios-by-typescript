$(function () {

  let flag = 1
  let flagTwo = 1
  let cover = 1
  // const graceArr = [1, 6, 7, 8, 9]
  const course = [[2014, 2], [2015, 2], [2017, 2], [2018, 2], [2019, 2]]
  // 风采 item 以及 切换张数
  const graceful = [[1, 2], [2, 4], [3, 6], [5, 2], [6, 4], [7, 4], [8, 3], [9, 3]]
  // 大事记 年份 以及 切换张数
  const forEvent = [[2015, 2], [2016, 3], [2017, 2], [2018, 4], [2019, 4]]
  // 数字变化类名
  const digital = ['first', 'second', 'third', 'fourth', 'fifth']


  $('.middle-img').click(function () {
    $('#video').css('display', 'block')
    $('#mask').css('display', 'block')
    $('#video')[0].play()
    $('.middle-img').css('display', 'none')
  });

  // 3+1 切换点击事件
  $('.cover .prev').click(() => {
    coverClick()
  })
  $('.cover .back').click(() => {
    coverClick()
  })


  // 重播点击事件
  $('.replay').click(() => {
    middleReset(true)
  })


  // 大事件点击返回
  $('.event-back').click(() => {
    eventReset()
  })


  // 标题点击事件
  $('.all>.header img').click(() => {
    backToInit()
    middleReset()
    $('.box-right .page-two .container .item p').css('color', "white")
    $('.box-middle .container').css('display', 'block')
    resetBackground()
    courseReset()
  })


  // 左侧切页
  $('.left-pre').click(() => {
    leftReset()
    if (flag === 3) {
      $('.box-left .page-two').css('display', 'block')
    } else if (flag === 2) {
      $('.box-left .page-one').css('display', 'block')
    } else if (flag === 1) {
      $('.box-left .page-three').css('display', 'block')
    }
    if (flag === 1) {
      flag = 4
    }
    resetBackground()
    middleReset()
    flag--
  })

  $('.left-back').click(() => {
    if (flag === 3) {
      flag = 0
    }
    leftReset()
    if (flag === 0) {
      $('.box-left .page-one').css('display', 'block')
    } else if (flag === 1) {
      $('.box-left .page-two').css('display', 'block')
    } else if (flag === 2) {
      $('.box-left .page-three').css('display', 'block')
    }
    resetBackground()
    middleReset()
    flag++
  })

  // 右侧切页
  $('.right-pre').click(() => {
    rightReset()
    if (flagTwo === 3) {
      $('.box-right .page-two').css('display', 'block')
    } else if (flagTwo === 2) {
      $('.box-right .page-one').css('display', 'block')
    } else if (flagTwo === 1) {
      $('.box-right .page-three').css('display', 'block')
    }
    if (flagTwo === 1) {
      flagTwo = 4
    }
    eventReset()
    middleReset()
    flagTwo--
  })

  $('.right-back').click(() => {
    rightReset()
    if (flagTwo === 3) {
      flagTwo = 0
    }
    if (flagTwo === 0) {
      $('.box-right .page-one').css('display', 'block')
    } else if (flagTwo === 1) {
      $('.box-right .page-two').css('display', 'block')
    } else if (flagTwo === 2) {
      $('.box-right .page-three').css('display', 'block')
    }
    eventReset()
    middleReset()
    flagTwo++
  })



  function backToInit(flag) {
    if (flag) {
      $('.box-middle .container').css('display', 'block')
      $('.graceful').css('display', 'none')
      $('.course').css('display', 'none')
      $('.cover').css('display', 'none')
      return
    }
    $('.cover').css('display', 'none')
    $('.course').css('display', 'none')
    $('.box-middle .container').css('display', 'none')
    $('.graceful').css('display', 'none')
  }
  // 重置风采图片为最初状态
  function resetBackground() {
    for (let i = 1; i <= 9; i++) {
      $(`.elegant .img-container img:nth-child(${i})`).attr('src', `./left/imgs/graceful/graceful${i}@before.png`)
    }
  }

  // 改变点击的风采背景图
  function changeBackground(index) {
    $(`.elegant .img-container img:nth-child(${index})`).attr('src', `./left/imgs/graceful/graceful${index}@after.png`)
  }

  // 大事记切换为最初状态
  function eventReset() {
    $('.summarize').css('display', 'block')
    $('.event').css('display', 'none')
  }

  // 左侧重置
  function leftReset() {
    backToInit(true)
    $('.box-left .page-one').css('display', 'none')
    $('.box-left .page-two').css('display', 'none')
    $('.box-left .page-three').css('display', 'none')
  }

  // 右侧重置
  function rightReset() {
    backToInit(true)
    $('.box-right .page-two .container .item p').css('color', "white")
    $('.box-right .page-one').css('display', 'none')
    $('.box-right .page-two').css('display', 'none')
    $('.box-right .page-three').css('display', 'none')
  }

  // 重置中间为初始状态
  function middleReset(options) {
    // 重播
    if (options) {
      $('#video')[0].currentTime = 0
      return
    }

    // 视频页返回初始状态
    $('#video')[0].currentTime = 0
    $('#video')[0].pause()
    $('#video').css('display', 'none')
    $('#mask').css('display', 'none')
    $('.middle-img').css('display', 'block')
  }

  // 风采翻页事件
  function graceHandleSwitch(options, whichItem, pages) {
    const reg = new RegExp(`describe${whichItem}-(\\d).png`)
    const src = $(`.graceful .item${whichItem} img`).attr('src')
    // 匹配img的url为第几张图片
    if (!src.match(reg).length) {
      return
    }
    const res = parseInt(src.match(reg)[1])

    if (options === 'back') {    // 点击后切换
      for (let j = 1; j <= pages; j++) {
        if (res === j) {
          if (j === pages) {    // 为最后一张图片
            $(`.graceful .item${whichItem} img`).attr('src', `./left/imgs/graceful/describe${whichItem}-1.png`)
            return
          }
          // 不为最后一张图片
          $(`.graceful .item${whichItem} img`).attr('src', `./left/imgs/graceful/describe${whichItem}-${j + 1}.png`)
          return
        }

      }
    } else if (options === 'pre') {     // 点击前切换
      for (let j = 1; j <= pages; j++) {    // 根据所传参数的图片数进行遍历
        if (res === j) {
          if (j === 1) {  // 为第一张图片
            $(`.graceful .item${whichItem} img`).attr('src', `./left/imgs/graceful/describe${whichItem}-${pages}.png`)
            return
          }
          // 不为第一张图片
          $(`.graceful .item${whichItem} img`).attr('src', `./left/imgs/graceful/describe${whichItem}-${j - 1}.png`)
          return
        }
      }
    }
  }

  // 大事记翻页事件
  function eventHandleSwitch(options, whichItem, pages) {
    const reg = new RegExp(`${whichItem}-(\\d).png`)
    const src = $(`.item${whichItem} img`).attr('src')
    // 匹配img的url为第几张图片
    if (!src.match(reg).length) {
      return
    }
    const res = parseInt(src.match(reg)[1])

    if (options === 'back') {    // 点击后切换
      for (let j = 1; j <= pages; j++) {
        if (res === j) {
          if (j === pages) {    // 为最后一张图片
            $(`.item${whichItem} img`).attr('src', `./left/imgs/event/${whichItem}-1.png`)
            return
          }
          // 不为最后一张图片
          $(`.item${whichItem} img`).attr('src', `./left/imgs/event/${whichItem}-${j + 1}.png`)
          return
        }

      }
    } else if (options === 'pre') {     // 点击前切换
      for (let j = 1; j <= pages; j++) {    // 根据所传参数的图片数进行遍历
        if (res === j) {
          if (j === 1) {  // 为第一张图片
            $(`.item${whichItem} img`).attr('src', `./left/imgs/event/${whichItem}-${pages}.png`)
            return
          }
          // 不为第一张图片
          $(`.item${whichItem} img`).attr('src', `./left/imgs/event/${whichItem}-${j - 1}.png`)
          return
        }
      }
    }
  }

  // 3+1 覆盖切页
  function coverClick() {
    if (cover % 2 === 1) {
      $('.cover .img img').attr('src', './left/imgs/cover/tools-2.png')
    } else {
      $('.cover .img img').attr('src', './left/imgs/cover/tools-1.png')
    }
    cover++
  }

  // 右侧第一页 数字改变事件
  (function () {
    for (let value of digital) {
      console.log(value)
      if (value === 'first') {
        setInterval(() => {
          let last = parseInt($(`.item.${value} .last`).text()) + 1
          let pre = parseInt($(`.item.${value} .pre`).text())
          if (last >= 10) {
            last = 0
            pre++
            if (pre === 10) {
              pre = 0
            }
            $(`.item.${value} .pre`).text(pre)
          }
          $(`.item.${value} .last`).text(last)
        }, 3000)
      } else {
        console.log('else')
        setInterval(() => {
          let rd = Math.floor(Math.random() * 10) % 5
          let last = parseInt($(`.item.${value} .last`).text()) + rd
          let pre = parseInt($(`.item.${value} .pre`).text())
          if (last >= 10) {
            last = 0
            pre++
            if (pre === 10) {
              pre = 0
            }
            $(`.item.${value} .pre`).text(pre)
          }
          $(`.item.${value} .last`).text(last)
        }, 30000)
      }
    }
  })();

  // 风采展示点击事件绑定
  (function () {
    for (let i = 1; i <= 9; i++) {
      $(`.elegant .img-container img:nth-child(${i})`).click((e) => {
        backToInit()
        $('.graceful').css('display', 'block')
        $('.graceful>div').css('display', 'none')
        resetBackground()
        changeBackground(i)
        $(`.graceful .item${i}`).css('display', 'block')
        middleReset()
        $('.box-right .page-two .container .item p').css('color', "white")
      })
    }
  })();

  // 大事记点击事件绑定
  (function () {
    for (let i = 1; i <= 6; i++) {
      $(`.summarize .img-container img:nth-child(${i})`).click(() => {
        $('.event>div').css('display', 'none')
        $('.summarize').css('display', 'none')
        $('.event').css('display', 'block')
        // 从2014开始
        $(`.event .item201${i + 3}`).css('display', 'block')
      })
    }
  })();

  // 3+1 点击事件绑定
  (function () {
    for (let i = 1; i <= 3; i++) {
      $(`.box-right .page-two .item:nth-of-type(${i})`).click(() => {
        backToInit()
        $('.cover').css('display', 'block')
        $('.box-right .page-two .container .item p').css('color', "white")
        if (i === 1) {
          $(`.box-right .page-two .item:nth-of-type(${i}) p`).css('color', "#FEC74D")
        } else if (i === 2) {
          $(`.box-right .page-two .item:nth-of-type(${i}) p`).css('color', "#44DCDA")
        } else if (i === 3) {
          $(`.box-right .page-two .item:nth-of-type(${i}) p`).css('color', "#43DA79")
        }
        $('.box-middle .cover .item').css('display', 'none')
        $(`.box-middle .cover .item${i}`).css('display', 'block')
        middleReset()
        courseReset()
        resetBackground()
      })
    }
  })();

  // 绑定风采翻页点击事件
  (function () {
    for (let value of graceful) {
      $(`.graceful .item${value[0]} .prev`).click(() => {
        graceHandleSwitch('pre', value[0], value[1])
      })
      $(`.graceful .item${value[0]} .back`).click(() => {
        graceHandleSwitch('back', value[0], value[1])
      })
    }
  })();

  // 绑定大事记翻页点击事件
  (function () {
    for (let value of forEvent) {
      $(`.item${value[0]} .prev`).click(() => {
        eventHandleSwitch('pre', value[0], value[1])
      })
      $(`.item${value[0]} .back`).click(() => {
        eventHandleSwitch('back', value[0], value[1])
      })
    }
  })();

  function courseReset() {
    $('.course .item').css('display', 'none')
    for (let i = 1; i <= 9; i++){
      $(`.course_201${i}`).attr('src',`./left/imgs/course/201${i}.png`)
    }
  }

  // 建设历程点击事件
  (function () {
    for (let i = 4; i <= 9; i++) {
      $(`.course_201${i}`).click(() => {
        backToInit()
        $('.course').css('display', 'block')
        $('.box-right .page-two .container .item p').css('color', "white")
        courseReset()
        $(`.course .course201${i}`).css('display', 'block')
        $(`.course_201${i}`).attr('src', `./left/imgs/course/201${i}@after.png`)
      })
    }
  })();

  // 建设历程切换按钮点击事件绑定
  (function () {
    for (let i of course) {
      $(`.course${i[0]} .prev`).click(() => {
        courseBindClick('pre', i[0], i[1])
      })

      $(`.course${i[0]} .back`).click(() => {
        courseBindClick('back', i[0], i[1])
      })
    }
  })()

  function courseBindClick(direction, item, page) {
    const reg = new RegExp(`${item}-(\\d).png`)
    const src = $(`.course${item} img`).attr('src')
    if (!src.match(reg).length) {
      return
    }
    const res = parseInt(src.match(reg)[1])
    for (let i = 1; i <= page; i++) {
      if (direction === 'pre') {
        if (res === i) {
          if (i === 1) {
            $(`.course${item} img`).attr('src', `./left/imgs/course_news/${item}-${page}.png`)
            return
          }
          $(`.course${item} img`).attr('src', `./left/imgs/course_news/${item}-${i - 1}.png`)
          return
        }
      } else if (direction === 'back') {
        if (res === i) {
          if (i === page) {
            $(`.course${item} img`).attr('src', `./left/imgs/course_news/${item}-1.png`)
            return
          }
          $(`.course${item} img`).attr('src', `./left/imgs/course_news/${item}-${i + 1}.png`)
          return
        }
      }
    }
  }
})
